class PINCardFactory implements CardFactory {
    @Override
    public AccessCard createCard() {
        return new PINCard();
    }
}