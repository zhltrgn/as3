class BuildingAccessControl extends AccessControlSystem {
    void grantAccess(String user) {
        System.out.println("Access granted for " + user);
        notifyAccessGranted(user);
    }
}