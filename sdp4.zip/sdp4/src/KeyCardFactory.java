class KeyCardFactory implements CardFactory {
    @Override
    public AccessCard createCard() {
        return new KeyCard();
    }
}