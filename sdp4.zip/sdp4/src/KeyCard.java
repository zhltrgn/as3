class KeyCard implements AccessCard {
    @Override
    public void use() {
        System.out.println("Using Key Card");
    }
}
class PINCard implements AccessCard {
    @Override
    public void use() {
        System.out.println("Using PIN Card");
    }
}