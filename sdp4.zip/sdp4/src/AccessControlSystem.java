import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;

class AccessControlSystem {
    private List<AccessControlListener> listeners = new ArrayList<>();

    void addObserver(AccessControlListener listener) {
        listeners.add(listener);
    }

    void notifyAccessGranted(String user) {
        for (AccessControlListener listener : listeners) {
            listener.onAccessGranted(user);
        }
    }
}