public class Main {
    public static void main(String[] args) {
        // Observer Pattern
        BuildingAccessControl accessControlSystem = new BuildingAccessControl();
        SecuritySystem securitySystem = new SecuritySystem("SecuritySystem1");
        accessControlSystem.addObserver(securitySystem);

        // Simulate access granted event
        accessControlSystem.grantAccess("User1");

        // Factory Pattern
        CardFactory keyCardFactory = new KeyCardFactory();
        CardFactory pinCardFactory = new PINCardFactory();

        AccessCard keyCard = keyCardFactory.createCard();
        AccessCard pinCard = pinCardFactory.createCard();

        keyCard.use();
        pinCard.use();
    }
}