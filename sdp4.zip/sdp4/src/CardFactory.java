interface CardFactory {
    AccessCard createCard();
}