interface AccessCard {
    void use();
}