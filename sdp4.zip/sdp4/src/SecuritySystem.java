class SecuritySystem implements AccessControlListener {
    private String name;

    public SecuritySystem(String name) {
        this.name = name;
    }

    @Override
    public void onAccessGranted(String user) {
        System.out.println(name + " received notification: Access granted to " + user);
    }
}