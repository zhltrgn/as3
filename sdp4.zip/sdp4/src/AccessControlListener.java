interface AccessControlListener {
    void onAccessGranted(String user);
}